@echo off
cd /d "%~dp0"
pythonw cubby_custom.py
