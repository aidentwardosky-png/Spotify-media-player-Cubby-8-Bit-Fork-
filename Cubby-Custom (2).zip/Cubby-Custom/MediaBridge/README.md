Native Windows SMTC bridge for Cubby Custom. It reads the current Windows media session and sends playback/seek commands for Spotify, browsers, VLC, and other SMTC-compatible apps.
