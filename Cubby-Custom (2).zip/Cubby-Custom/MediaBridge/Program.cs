using System.Text.Json;
using Windows.Media.Control;
using Windows.Storage.Streams;

var command = args.Length > 0 ? args[0].ToLowerInvariant() : "status";
var manager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
var session = manager.GetSessions()
    .FirstOrDefault(item => item.SourceAppUserModelId.Contains("spotify", StringComparison.OrdinalIgnoreCase))
    ?? manager.GetCurrentSession();

if (session is null)
{
    Console.WriteLine("null");
    return;
}

if (command == "playpause")
{
    await session.TryTogglePlayPauseAsync();
    return;
}

if (command == "pause")
{
    await session.TryPauseAsync();
    return;
}

if (command == "previous")
{
    await session.TrySkipPreviousAsync();
    return;
}

if (command == "next")
{
    await session.TrySkipNextAsync();
    return;
}

if (command == "shuffle" && args.Length > 1 && bool.TryParse(args[1], out var shuffle))
{
    await session.TryChangeShuffleActiveAsync(shuffle);
    return;
}

if (command == "repeat" && args.Length > 1 && int.TryParse(args[1], out var repeat))
{
    await session.TryChangeAutoRepeatModeAsync((Windows.Media.MediaPlaybackAutoRepeatMode)repeat);
    return;
}

if (command == "seek" && args.Length > 1 && double.TryParse(args[1], out var seconds))
{
    await session.TryChangePlaybackPositionAsync(TimeSpan.FromSeconds(seconds).Ticks);
    return;
}

var properties = await session.TryGetMediaPropertiesAsync();
var timeline = session.GetTimelineProperties();
var playback = session.GetPlaybackInfo();
var artworkPath = "";
if (properties.Thumbnail is not null)
{
    try
    {
        using var stream = await properties.Thumbnail.OpenReadAsync();
        var reader = new DataReader(stream);
        await reader.LoadAsync((uint)stream.Size);
        var bytes = new byte[stream.Size];
        reader.ReadBytes(bytes);
        reader.Dispose();
        artworkPath = Path.Combine(Path.GetTempPath(), "cubby-current-artwork.jpg");
        await File.WriteAllBytesAsync(artworkPath, bytes);
    }
    catch
    {
        artworkPath = "";
    }
}
var result = new
{
    title = properties.Title,
    artist = properties.Artist,
    album = properties.AlbumTitle,
    position = timeline.Position.TotalSeconds,
    duration = timeline.EndTime.TotalSeconds,
    start = timeline.StartTime.TotalSeconds,
    status = playback.PlaybackStatus.ToString(),
    source = session.SourceAppUserModelId,
    artwork = artworkPath,
};
Console.WriteLine(JsonSerializer.Serialize(result));
