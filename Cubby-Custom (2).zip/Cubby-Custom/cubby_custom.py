import ctypes
import math
import random
import subprocess
import json
import queue
import threading
import time
from ctypes import wintypes
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk
from PIL import Image, ImageEnhance, ImageFilter, ImageGrab, ImageTk
from pycaw.pycaw import AudioUtilities


user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
dwmapi = ctypes.windll.dwmapi
gdi32.CreateRoundRectRgn.restype = ctypes.c_void_p
user32.SetWindowRgn.argtypes = [wintypes.HWND, ctypes.c_void_p, wintypes.BOOL]
DWMWA_SYSTEMBACKDROP_TYPE = 38
DWMWA_WINDOW_CORNER_PREFERENCE = 33
VK_MEDIA_PREV_TRACK = 0xB1
VK_MEDIA_NEXT_TRACK = 0xB0
VK_MEDIA_PLAY_PAUSE = 0xB3
VK_VOLUME_MUTE = 0xAD
KEYEVENTF_KEYUP = 0x0002


class CubbyCustom:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", "#111318")
        self.root.attributes("-alpha", 0.82)
        self.root.configure(bg="#111318")

        self.width = 1120
        self.height = 96
        self.visible = False
        self.animating = False
        self.sliding = False
        self.slide_start_y = 0
        self.slide_target_y = 0
        self.slide_started_at = 0.0
        self.scaling = False
        self.scale = 1.0
        self.hover_target = None
        self.loading = True
        self.loading_items = []
        self.shuffle_enabled = False
        self.repeat_enabled = False
        self.snooze_block = False
        self.volume_level = 1.0
        self.volume_slider_items = []
        self.glass_background_image = None
        self.artwork_item = None
        self.artwork_scale = 1.0
        self.artwork_bounce_offset = 0.0
        self.artwork_animation_started = 0.0
        self.popout = None
        self.popout_canvas = None
        self.popout_artwork_image = None
        self.popout_drag_origin = None
        self.popout_size = 260
        self.popout_rack_open = False
        self.popout_rack_index = 0
        self.popout_rack_job = None
        self.popout_rack_offset = 0.0
        self.rack_window = None
        self.rack_canvas = None
        self.rack_hide_job = None
        self.rack_visible = False
        self.artwork_history = []
        self.comet_items = []
        self.comet_specs = []
        self.background_dot_items = []
        self.floating_items = []
        self.float_offset = 0.0
        self.float_phase = 0.0
        self.float_offset = 0.0
        self.closing = False
        self.next_comet_at = time.perf_counter() + random.uniform(10, 15)
        self.music_phase = 0.0
        self.control_offset = 0.0
        self.control_items = []
        self.hover_values = {
            "title": 0.0,
            "subtitle": 0.0,
            "prev": 0.0,
            "play": 0.0,
            "next": 0.0,
            "shuffle": 0.0,
            "repeat": 0.0,
            "device": 0.0,
            "volume": 0.0,
            "snooze": 0.0,
            "close": 0.0,
        }
        self.hover_growth = {name: 0.0 for name in self.hover_values}
        self.button_geometry = {}
        self.icon_pulses = {}
        self.icon_font_specs = {}
        self.hide_job = None
        self.progress = 0.38
        self.target_progress = self.progress
        self.progress_items = []
        self.elapsed_seconds = 0.0
        self.duration_seconds = None
        self.time_label_item = None
        self.spotify_running = False
        self.media_title = "Now Playing"
        self.media_artist = "Connect a media app to see track details"
        self.media_status = ""
        self.is_playing = False
        self.last_progress_tick = time.perf_counter()
        self.media_updates = queue.Queue()
        self.media_worker_stop = threading.Event()
        self.artwork_path = ""
        self.artwork_image = None
        self.hover_items = {}
        self.button_geometry = {}
        self.bridge_path = str(__import__("pathlib").Path(__file__).parent / "MediaBridge" / "bin" / "Release" / "net10.0-windows10.0.22621.0" / "MediaBridge.dll")
        self.dragging = False
        self.orb_phase = 0.0
        self.orb_particle_items = []
        self.orb_core_items = []
        self.artwork_item = None
        orb_colors = ("#7cecff", "#5b8dff", "#b66dff", "#ff6fbd", "#ff9a70")
        self.orb_particles = [
            (random.random() * math.tau, 11 + random.random() * 17, random.choice(orb_colors), 0.45 + random.random() * 0.95)
            for _ in range(90)
        ]

        self.panel = tk.Frame(
            self.root,
            bg="#111318",
            highlightbackground="#a5bac7",
            highlightthickness=1,
        )
        self.panel.pack(fill="both", expand=True)
        self.apply_glass_effect()

        self.canvas = tk.Canvas(
            self.panel,
            bg="#111318",
            highlightthickness=0,
            width=self.width,
            height=self.height,
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_seek_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_seek_release)
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<Leave>", self.schedule_hide)

        self.root.bind("<Escape>", lambda _event: self.hide())
        self.root.after(50, self.poll_pointer)
        self.root.after(1000, self.refresh)
        self.root.after(40, self.animate_orb)
        self.root.after(40, self.animate_hover)
        self.root.after(40, self.animate_progress)
        self.root.after(40, self.animate_controls)
        self.root.after(16, self.animate_icon_pulses)
        self.root.after(80, self.animate_loading)
        self.root.after(40, self.animate_comets)
        self.root.after(80, self.animate_background)
        threading.Thread(target=self.media_worker, daemon=True).start()

        # CUSTOM CODE: add your own startup behavior here.
        self.on_startup()

    def on_startup(self):
        """Put custom code that should run once when Cubby starts here."""

    def custom_tick(self):
        """Put repeating custom code here. It runs once per second."""

    def draw(self):
        self.canvas.delete("all")
        self.control_items = []
        self.hover_items = {}
        self.button_geometry = {}
        self.hover_growth = {name: 0.0 for name in self.hover_values}
        self.icon_pulses = {}
        self.icon_font_specs = {}
        self.comet_items = []
        self.background_dot_items = []
        self.floating_items = []
        self.control_offset = 0.0
        self.orb_particle_items = []
        self.orb_core_items = []
        width = self.canvas.winfo_width() or self.width
        height = self.canvas.winfo_height() or self.height

        if self.glass_background_image:
            self.canvas.create_image(0, 0, anchor="nw", image=self.glass_background_image)
        else:
            self.canvas.create_rectangle(0, 0, width, height, fill="#3b4b56", outline="")
        self.canvas.create_rectangle(0, 0, width, height, fill="#3b4b56", stipple="gray50", outline="#a5bac7", width=1)
        self.canvas.create_rectangle(2, 2, width - 2, height - 2, outline="#637782", width=1)
        self.draw_glass_texture(width, height)
        self.draw_reflections(width, height)
        self.comet_layer_anchor = self.canvas.create_rectangle(0, 0, 0, 0, state="hidden")
        self.restore_comets()
        if self.loading:
            self.draw_loading(width, height)
            return
        self.draw_artwork()

        title_font = tkfont.Font(family="Segoe UI Semibold", size=12, weight="bold")
        title_text = self.wrap_title(self.media_title, title_font, 402)
        title_width = min(420, max(118, max(title_font.measure(line) for line in title_text.split("\n")) + 18))
        title_right = 78 + title_width
        self.title_right = title_right
        self.hover_items["title_box"] = self.rounded_rect(78, 14, title_right, 45, 12, self.hover_fill("title"), "")
        self.button_geometry["title"] = ((78 + title_right) / 2, (14 + 45) / 2, title_right - 78)
        self.hover_items["title_text"] = self.canvas.create_text(
            86, 16, anchor="nw", width=title_width - 16,
            text=title_text,
            fill=self.hover_text("title"),
            font=title_font,
        )
        subtitle_font = tkfont.Font(family="Segoe UI", size=9)
        subtitle_text = self.fit_text(self.media_artist, subtitle_font, 402)
        subtitle_width = min(420, max(118, subtitle_font.measure(subtitle_text) + 18))
        subtitle_right = 78 + subtitle_width
        self.subtitle_right = subtitle_right
        self.hover_items["subtitle_box"] = self.rounded_rect(78, 45, subtitle_right, 68, 10, self.hover_fill("subtitle"), "")
        self.button_geometry["subtitle"] = ((78 + subtitle_right) / 2, (45 + 68) / 2, subtitle_right - 78)
        self.hover_items["subtitle_text"] = self.canvas.create_text(
            86, 56, anchor="w",
            text=subtitle_text,
            fill=self.hover_text("subtitle"), font=("Segoe UI", 9),
        )
        center = width // 2
        self.control_items = [
            self.rounded_rect(center - 94, 13, center - 56, 49, 16, self.hover_fill("prev"), ""),
            self.rounded_rect(center - 24, 8, center + 24, 56, 24, self.hover_fill("play"), ""),
            self.rounded_rect(center + 56, 13, center + 94, 49, 16, self.hover_fill("next"), ""),
            self.canvas.create_text(center - 75, 31, text="|<", fill=self.hover_text("prev"), font=("Segoe UI", 11, "bold")),
            self.canvas.create_text(center, 32, text="⏸" if self.is_playing else "▶", fill=self.hover_text("play"), font=("Segoe UI", 15)),
            self.canvas.create_text(center + 75, 31, text="|>", fill=self.hover_text("next"), font=("Segoe UI", 11, "bold")),
        ]
        self.button_geometry.update({
            "prev": (center - 75, 31, 38),
            "play": (center, 32, 48),
            "next": (center + 75, 31, 38),
        })
        self.hover_items.update({
            "prev_box": self.control_items[0], "play_box": self.control_items[1], "next_box": self.control_items[2],
            "prev_text": self.control_items[3], "play_text": self.control_items[4], "next_text": self.control_items[5],
        })
        self.icon_font_specs.update({
            "prev": ("Segoe UI", 11, "bold"),
            "play": ("Segoe UI", 15, "normal"),
            "next": ("Segoe UI", 11, "bold"),
        })
        utility_left = width - 260
        utility_icons = ("⇄", "▤", "◫", "◖", "Z", "×")
        utility_names = ("shuffle", "repeat", "device", "volume", "snooze", "close")
        for index, (icon, name) in enumerate(zip(utility_icons, utility_names)):
            left = utility_left + index * 40
            item = self.rounded_rect(left, 16, left + 30, 48, 10, self.hover_fill(name), "")
            text_item = self.canvas.create_text(left + 15, 32, text=icon, fill=self.hover_text(name), font=("Segoe UI", 12, "bold" if name == "close" else "normal"))
            self.icon_font_specs[name] = ("Segoe UI", 12, "bold" if name == "close" else "normal")
            self.hover_items[f"{name}_box"] = item
            self.hover_items[f"{name}_text"] = text_item
            self.button_geometry[name] = (left + 15, 32, 30)

        self.volume_level = self.get_volume_level()
        volume_left = width - 260
        volume_right = width - 90
        self.canvas.create_text(volume_left, 70, anchor="w", text="VOL", fill="#a9bac4", font=("Segoe UI", 7, "bold"))
        self.canvas.create_rectangle(volume_left + 25, 70, volume_right, 74, fill="#34434d", outline="")
        self.volume_slider_items = [
            self.canvas.create_rectangle(volume_left + 25, 70, volume_left + 25 + (volume_right - volume_left - 25) * self.volume_level, 74, fill="#b6d0e8", outline=""),
            self.canvas.create_oval(0, 0, 0, 0, fill="#e9f1ff", outline=""),
        ]
        self.update_volume_slider()

        track_left = 300
        track_right = width - 300
        track_y = 64
        self.canvas.create_rectangle(
            track_left, track_y, track_right, track_y + 5,
            fill="#4a4e55", outline="", width=0,
        )
        self.progress_items = [
            self.canvas.create_line(
                track_left, track_y + 2, track_left + (track_right - track_left) * self.progress,
                track_y + 2, fill="#89aee8", width=3, capstyle="round", smooth=True,
            ),
            self.canvas.create_oval(0, 0, 0, 0, fill="#e7efff", outline=""),
        ]
        self.time_label_item = self.canvas.create_text(
            track_left - 35, track_y + 2, anchor="e", text=self.format_time(self.elapsed_seconds),
            fill="#e9edf5", font=("Segoe UI", 8),
        )
        self.duration_label_item = self.canvas.create_text(
            track_right + 18, track_y + 2, anchor="w", text=self.format_time(self.duration_seconds) if self.duration_seconds is not None else "-1:13",
            fill="#e9edf5", font=("Segoe UI", 8),
        )
        self.floating_items = list(dict.fromkeys(self.hover_items.values()))
        self.update_progress()

    def draw_loading(self, width, height):
        self.canvas.create_text(width // 2, 35, text="Loading media", fill="#e8edf5", font=("Segoe UI Semibold", 12))
        self.loading_items = [
            self.canvas.create_oval(width // 2 - 24 + index * 16, 55, width // 2 - 16 + index * 16, 63, fill="#7894bd", outline="")
            for index in range(3)
        ]

    def draw_glass_texture(self, width, height):
        for index in range(72):
            x = 8 + (index * 83) % max(12, width - 16)
            y = 7 + (index * 47) % max(12, height - 14)
            color = "#52636d" if index % 3 else "#60727d"
            self.background_dot_items.append(self.canvas.create_oval(x, y, x + 1, y + 1, fill=color, outline=""))
        self.canvas.create_line(8, 8, width - 8, 8, fill="#96afbd", width=1)
        self.canvas.create_line(16, height - 8, width - 16, height - 8, fill="#2b3b45", width=1)

    def draw_reflections(self, width, height):
        reflection = "#c4e1ed"
        self.canvas.create_polygon(
            width - 250, height + 12, width - 118, height + 12,
            width - 8, height - 58, width - 8, height - 32,
            smooth=True, fill=reflection, stipple="gray50", outline="",
        )
        self.canvas.create_polygon(
            width - 175, height + 8, width - 75, height + 8,
            width + 8, height - 42, width + 8, height - 26,
            smooth=True, fill="#e5f4f8", stipple="gray75", outline="",
        )

    def animate_comets(self):
        now = time.perf_counter()
        if self.visible:
            if now >= self.next_comet_at:
                self.spawn_comet()
                self.next_comet_at = now + random.uniform(10, 15)
            survivors = []
            for comet in self.comet_items:
                comet["x"] -= comet["speed"]
                comet["y"] += comet["drift"]
                head = comet["head"]
                tail = comet["tail"]
                self.canvas.coords(head, comet["x"] - 2, comet["y"] - 2, comet["x"] + 2, comet["y"] + 2)
                direction = math.hypot(comet["speed"], comet["drift"])
                tail_x = comet["x"] + comet["speed"] / direction * 46
                tail_y = comet["y"] - comet["drift"] / direction * 46
                self.canvas.coords(tail, comet["x"], comet["y"], tail_x, tail_y)
                if comet["x"] > -80:
                    survivors.append(comet)
                else:
                    self.canvas.delete(head, tail)
            self.comet_items = survivors
            self.comet_specs = [
                {key: comet[key] for key in ("x", "y", "speed", "drift", "color")}
                for comet in survivors
            ]
        self.root.after(40, self.animate_comets)

    def spawn_comet(self):
        width = self.canvas.winfo_width() or self.width
        height = self.canvas.winfo_height() or self.height
        x = width + 16
        y = random.uniform(10, max(12, height - 18))
        color = random.choice(("#d9f3ff", "#f2e8ff", "#d8e8ff"))
        speed = random.uniform(3.0, 5.0)
        drift = random.uniform(0.05, 0.22)
        direction = math.hypot(speed, drift)
        tail = self.canvas.create_line(
            x, y, x + speed / direction * 46, y - drift / direction * 46,
            fill=color, width=1, capstyle="round",
        )
        head = self.canvas.create_oval(x - 2, y - 2, x + 2, y + 2, fill="#ffffff", outline="")
        self.canvas.tag_lower(tail, self.comet_layer_anchor)
        self.canvas.tag_lower(head, self.comet_layer_anchor)
        comet = {"head": head, "tail": tail, "x": x, "y": y, "speed": speed, "drift": drift, "color": color}
        self.comet_items.append(comet)
        self.comet_specs.append({key: comet[key] for key in ("x", "y", "speed", "drift", "color")})

    def restore_comets(self):
        self.comet_items = []
        for spec in self.comet_specs:
            direction = math.hypot(spec["speed"], spec["drift"])
            tail = self.canvas.create_line(
                spec["x"], spec["y"],
                spec["x"] + spec["speed"] / direction * 46,
                spec["y"] - spec["drift"] / direction * 46,
                fill=spec["color"], width=1, capstyle="round",
            )
            head = self.canvas.create_oval(spec["x"] - 2, spec["y"] - 2, spec["x"] + 2, spec["y"] + 2, fill="#ffffff", outline="")
            self.canvas.tag_lower(tail, self.comet_layer_anchor)
            self.canvas.tag_lower(head, self.comet_layer_anchor)
            self.comet_items.append({**spec, "head": head, "tail": tail})

    def finish_loading(self):
        self.loading = False
        if self.visible:
            self.draw()

    def animate_loading(self):
        if self.loading and self.visible and self.loading_items:
            active = int(time.perf_counter() * 4) % 3
            for index, item in enumerate(self.loading_items):
                self.canvas.itemconfigure(item, fill="#dce8ff" if index == active else "#526580")
        self.root.after(80, self.animate_loading)

    def pulse_button(self, name):
        if name in self.icon_font_specs:
            self.icon_pulses[name] = time.perf_counter()

    def animate_icon_pulses(self):
        now = time.perf_counter()
        for name, started in list(self.icon_pulses.items()):
            progress = (now - started) / 0.30
            item = self.hover_items.get(f"{name}_text")
            spec = self.icon_font_specs.get(name)
            if not item or not spec:
                self.icon_pulses.pop(name, None)
                continue
            if progress >= 1.0:
                amount = 1.0
                self.icon_pulses.pop(name, None)
            else:
                amount = 1.0 + 0.20 * math.sin(math.pi * progress)
            family, size, weight = spec
            self.canvas.itemconfigure(item, font=(family, max(1, round(size * amount)), weight))
        self.root.after(16, self.animate_icon_pulses)

    def get_volume_level(self):
        try:
            device = AudioUtilities.GetSpeakers()
            return max(0.0, min(1.0, float(device.EndpointVolume.GetMasterVolumeLevelScalar())))
        except Exception:
            return 1.0

    def set_volume_level(self, value):
        self.volume_level = max(0.0, min(1.0, value))
        try:
            device = AudioUtilities.GetSpeakers()
            device.EndpointVolume.SetMasterVolumeLevelScalar(self.volume_level, None)
        except Exception:
            pass
        self.update_volume_slider()

    def update_volume_slider(self):
        if len(self.volume_slider_items) != 2:
            return
        left = self.canvas.winfo_width() - 260 + 25
        right = self.canvas.winfo_width() - 90
        x = left + (right - left) * self.volume_level
        self.canvas.coords(self.volume_slider_items[0], left, 70, x, 74)
        self.canvas.coords(self.volume_slider_items[1], x - 4, 68, x + 4, 76)

    @staticmethod
    def fit_text(text, font, max_width):
        if font.measure(text) <= max_width:
            return text
        suffix = "..."
        while text and font.measure(text + suffix) > max_width:
            text = text[:-1]
        return text.rstrip() + suffix

    @staticmethod
    def wrap_title(text, font, max_width):
        words = text.split()
        if not words:
            return "Now Playing"
        lines = []
        current = words[0]
        for word in words[1:]:
            candidate = f"{current} {word}"
            if font.measure(candidate) <= max_width:
                current = candidate
            else:
                lines.append(current)
                current = word
        lines.append(current)
        return "\n".join(lines[:2])

    def draw_artwork(self):
        if self.artwork_path:
            try:
                image = Image.open(self.artwork_path).convert("RGB")
                image.thumbnail((64, 64), Image.Resampling.LANCZOS)
                self.artwork_image = ImageTk.PhotoImage(image)
                self.artwork_item = self.canvas.create_image(42, 44, image=self.artwork_image)
                if self.artwork_scale != 1.0:
                    self.canvas.scale(self.artwork_item, 42, 44, self.artwork_scale, self.artwork_scale)
                return
            except (OSError, ValueError):
                self.artwork_image = None
        self.rounded_rect(10, 12, 74, 76, 10, "#eff1e8", "")
        self.canvas.create_oval(20, 21, 64, 65, outline="#75786e", width=1)
        self.canvas.create_oval(30, 31, 54, 55, outline="#9c9f96", width=1)
        self.canvas.create_text(42, 44, text="VOL I", fill="#272b2b", font=("Segoe UI", 8, "bold"))
        self.canvas.create_text(42, 62, text="●", fill="#b5b8ae", font=("Segoe UI", 8))

    def time_label(self):
        elapsed = self.format_time(self.elapsed_seconds)
        duration = self.format_time(self.duration_seconds) if self.duration_seconds is not None else "??:??"
        return f"{elapsed} / {duration}"

    @staticmethod
    def format_time(seconds):
        seconds = max(0, int(seconds))
        return f"{seconds // 60}:{seconds % 60:02d}"

    def hover_fill(self, name):
        return self.mix_color("#151820", "#f1f3f7", self.hover_values[name])

    def hover_text(self, name):
        return self.mix_color("#dbe4f5", "#111318", self.hover_values[name])

    @staticmethod
    def mix_color(start, end, amount):
        amount = max(0.0, min(1.0, amount))
        start_rgb = tuple(int(start[index:index + 2], 16) for index in (1, 3, 5))
        end_rgb = tuple(int(end[index:index + 2], 16) for index in (1, 3, 5))
        mixed = tuple(round(first + (second - first) * amount) for first, second in zip(start_rgb, end_rgb))
        return "#%02x%02x%02x" % mixed

    def rounded_rect(self, left, top, right, bottom, radius, fill, outline):
        radius = min(radius, (right - left) / 2, (bottom - top) / 2)
        points = []
        for center_x, center_y, start_angle in (
            (right - radius, top + radius, -90),
            (right - radius, bottom - radius, 0),
            (left + radius, bottom - radius, 90),
            (left + radius, top + radius, 180),
        ):
            for step in range(7):
                angle = math.radians(start_angle + step * 15)
                points.extend((center_x + radius * math.cos(angle), center_y + radius * math.sin(angle)))
        return self.canvas.create_polygon(points, fill=fill, outline=outline, smooth=True)

    def draw_orb(self):
        center_x = 48
        center_y = 50 + math.sin(self.orb_phase * 0.65) * 2.5
        self.orb_core_items = [
            self.canvas.create_oval(14, 16, 82, 84, fill="#1a2035", outline=""),
            self.canvas.create_oval(20, 22, 76, 78, fill="#20254a", outline=""),
            self.canvas.create_oval(27, 29, 69, 71, fill="#2d2b62", outline=""),
        ]

        for index, (angle, radius, color, size) in enumerate(self.orb_particles):
            item = self.canvas.create_oval(0, 0, 0, 0, fill=color, outline="")
            self.orb_particle_items.append((item, angle, radius, size))

        self.orb_core_items.extend((
            self.canvas.create_oval(38, 40, 58, 60, fill="#6f84ff", outline=""),
            self.canvas.create_oval(42, 43, 54, 56, fill="#b9c7ff", outline=""),
        ))
        self.update_orb()

    def update_orb(self):
        center_x = 48
        center_y = 50 + math.sin(self.orb_phase * 0.65) * 2.5
        for index, (item, angle, radius, size) in enumerate(self.orb_particle_items):
            wave = math.sin(self.orb_phase * 1.4 + index * 0.7) * 2.2
            current_radius = radius + wave
            x = center_x + math.cos(angle + self.orb_phase * 0.35) * current_radius
            y = center_y + math.sin(angle + self.orb_phase * 0.35) * current_radius * 0.82
            self.canvas.coords(item, x - size, y - size, x + size, y + size)
        if len(self.orb_core_items) == 5:
            self.canvas.coords(self.orb_core_items[0], 14, 16, 82, 84)
            self.canvas.coords(self.orb_core_items[1], 20, 22, 76, 78)
            self.canvas.coords(self.orb_core_items[2], 27, 29, 69, 71)
            self.canvas.coords(self.orb_core_items[3], 38, 40, 58, 60)
            self.canvas.coords(self.orb_core_items[4], 42, 43, 54, 56)

    def animate_orb(self):
        self.orb_phase += 0.025
        if self.visible:
            self.update_orb()
        self.root.after(40, self.animate_orb)

    def animate_controls(self):
        self.music_phase += 0.16
        self.float_phase += 0.10
        next_float = math.sin(self.float_phase) * 1.4
        float_delta = next_float - self.float_offset
        self.float_offset = next_float
        for item in self.floating_items:
            self.canvas.move(item, 0, float_delta)
        if self.visible and self.control_items:
            beat = (math.sin(self.music_phase) + 1.0) / 2.0
            next_offset = -1.5 - beat * 3.5
            delta = next_offset - self.control_offset
            self.control_offset = next_offset
            self.canvas.move(self.control_items[0], 0, delta * 0.55)
            self.canvas.move(self.control_items[1], 0, delta)
            self.canvas.move(self.control_items[2], 0, delta * 0.55)
            self.canvas.move(self.control_items[3], 0, delta * 0.55)
            self.canvas.move(self.control_items[4], 0, delta)
            self.canvas.move(self.control_items[5], 0, delta * 0.55)
        self.root.after(40, self.animate_controls)

    def animate_background(self):
        if self.visible and self.background_dot_items:
            pulse = (math.sin(time.perf_counter() * 1.4) + 1.0) / 2.0
            for index, item in enumerate(self.background_dot_items):
                color = "#6b7f88" if (index + int(pulse * 3)) % 3 == 0 else "#465862"
                self.canvas.itemconfigure(item, fill=color)
        self.root.after(80, self.animate_background)

    def animate_progress(self):
        now = time.perf_counter()
        elapsed = now - self.last_progress_tick
        self.last_progress_tick = now
        if self.is_playing and self.duration_seconds:
            self.progress = min(1.0, self.progress + elapsed / self.duration_seconds)
            self.target_progress = min(1.0, self.target_progress + elapsed / self.duration_seconds)
        distance = self.target_progress - self.progress
        if abs(distance) > 0.001:
            self.progress += distance * 0.10
        if self.visible and (self.is_playing or abs(distance) > 0.001):
            self.update_progress()
        self.root.after(40, self.animate_progress)

    def update_progress(self):
        if not self.progress_items:
            return
        track_left = 300
        track_right = self.canvas.winfo_width() - 300
        track_y = 64
        end_x = track_left + (track_right - track_left) * self.progress
        if self.is_playing:
            points = []
            wave_width = max(1.0, end_x - track_left)
            sample_count = max(2, int(wave_width / 4))
            for index in range(sample_count):
                x = track_left + wave_width * index / (sample_count - 1)
                y = track_y + 2 + math.sin((x - track_left) * math.tau / 50 + self.orb_phase * 0.5) * 1.8
                points.extend((x, y))
            self.canvas.coords(self.progress_items[0], *points)
        else:
            self.canvas.coords(self.progress_items[0], track_left, track_y + 2, end_x, track_y + 2)
        self.canvas.itemconfigure(self.progress_items[0], fill="#89aee8")
        thumb_x = track_left + (track_right - track_left) * self.progress
        self.canvas.coords(self.progress_items[1], thumb_x - 4, track_y - 2, thumb_x + 4, track_y + 6)
        if self.time_label_item:
            self.canvas.itemconfigure(self.time_label_item, text=self.format_time(self.elapsed_seconds))
        if getattr(self, "duration_label_item", None):
            self.canvas.itemconfigure(
                self.duration_label_item,
                text=self.format_time(self.duration_seconds) if self.duration_seconds is not None else "-1:13",
            )

    def animate_hover(self):
        for name, value in self.hover_values.items():
            target = 1.0 if self.hover_target == name else 0.0
            next_value = value + (target - value) * 0.18
            self.hover_values[name] = next_value
            if self.visible:
                self.canvas.itemconfigure(self.hover_items.get(f"{name}_box"), fill=self.hover_fill(name))
                self.canvas.itemconfigure(self.hover_items.get(f"{name}_text"), fill=self.hover_text(name))
                if name in self.button_geometry:
                    current_growth = self.hover_growth[name]
                    target_growth = 15.0 if self.hover_target == name else 0.0
                    next_growth = current_growth + (target_growth - current_growth) * 0.20
                    if abs(next_growth - current_growth) > 0.01:
                        center_x, center_y, base_width = self.button_geometry[name]
                        scale = (base_width + next_growth) / (base_width + current_growth)
                        for item_name in (f"{name}_box", f"{name}_text"):
                            item = self.hover_items.get(item_name)
                            if item:
                                self.canvas.scale(item, center_x, center_y, scale, scale)
                        self.hover_growth[name] = next_growth
        self.root.after(40, self.animate_hover)

    def show(self):
        if self.hide_job:
            self.root.after_cancel(self.hide_job)
            self.hide_job = None
        screen_width = self.root.winfo_screenwidth()
        x = (screen_width - self.width) // 2
        if not self.visible:
            self.visible = True
            self.scale = 0.96
            self.artwork_scale = 0.55
            self.artwork_bounce_offset = 0.0
            self.artwork_animation_started = time.perf_counter()
            start_width = int(self.width * self.scale)
            start_height = int(self.height * self.scale)
            self.capture_glass_background((screen_width - self.width) // 2, 0, self.width, self.height)
            self.root.geometry(f"{start_width}x{start_height}+{(screen_width - start_width) // 2}+{-start_height - 2}")
            self.root.deiconify()
            self.apply_rounded_region(start_width, start_height)
            self.draw()
            self.begin_slide(0)
            self.animate_scale()
            self.animate_artwork()
            self.root.after(800, self.finish_loading)

    def capture_glass_background(self, left, top, width, height):
        try:
            image = ImageGrab.grab(bbox=(left, top, left + width, top + height)).convert("RGB")
            blurred = image.filter(ImageFilter.GaussianBlur(11))
            blurred = ImageEnhance.Color(blurred).enhance(0.75)
            tint = Image.new("RGB", blurred.size, "#344651")
            morphed = Image.blend(blurred, tint, 0.38)
            self.glass_background_image = ImageTk.PhotoImage(morphed)
        except (OSError, ValueError):
            self.glass_background_image = None

    def hide(self):
        if self.visible and not self.animating:
            self.visible = False
            self.begin_slide(-self.height - 2)

    def begin_slide(self, target_y):
        self.sliding = True
        self.animating = True
        self.slide_start_y = self.root.winfo_y()
        self.slide_target_y = target_y
        self.slide_started_at = time.perf_counter()
        self.animate_to()

    def animate_to(self):
        elapsed = time.perf_counter() - self.slide_started_at
        progress = min(1.0, elapsed / 0.48)
        eased = progress * progress * (3.0 - 2.0 * progress)
        current_y = round(self.slide_start_y + (self.slide_target_y - self.slide_start_y) * eased)
        current_width = int(self.width * self.scale)
        current_height = int(self.height * self.scale)
        screen_width = self.root.winfo_screenwidth()
        self.root.geometry(
            f"{current_width}x{current_height}+{(screen_width - current_width) // 2}+{current_y}"
        )
        if progress < 1.0:
            self.root.after(16, self.animate_to)
        else:
            self.sliding = False
            self.animating = False

    def animate_scale(self):
        if self.scale >= 1.0:
            self.scaling = False
            return
        self.scaling = True
        self.scale = min(1.0, self.scale + 0.01)
        screen_width = self.root.winfo_screenwidth()
        current_width = int(self.width * self.scale)
        current_height = int(self.height * self.scale)
        self.root.geometry(
            f"{current_width}x{current_height}+{(screen_width - current_width) // 2}+{self.root.winfo_y()}"
        )
        self.apply_rounded_region(current_width, current_height)
        self.root.after(16, self.animate_scale)

    def animate_artwork(self):
        if not self.artwork_item:
            return
        progress = min(1.0, (time.perf_counter() - self.artwork_animation_started) / 0.62)
        eased = 1.0 - (1.0 - progress) ** 3
        next_scale = 0.55 + 0.45 * eased + 0.20 * math.sin(math.pi * eased)
        scale_ratio = next_scale / self.artwork_scale
        self.canvas.scale(self.artwork_item, 42, 44, scale_ratio, scale_ratio)
        self.artwork_scale = next_scale
        next_offset = -12.0 * math.sin(progress * math.pi * 2.4) * (1.0 - progress)
        self.canvas.move(self.artwork_item, 0, next_offset - self.artwork_bounce_offset)
        self.artwork_bounce_offset = next_offset
        if progress < 1.0:
            self.root.after(16, self.animate_artwork)
        else:
            self.artwork_scale = 1.0
            self.artwork_bounce_offset = 0.0

    def apply_rounded_region(self, width, height, window=None):
        hwnd = (window or self.root).winfo_id()
        region = gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, 24, 24)
        user32.SetWindowRgn(hwnd, region, True)

    def apply_glass_effect(self):
        try:
            hwnd = self.root.winfo_id()
            backdrop = ctypes.c_int(3)
            corners = ctypes.c_int(2)
            dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, ctypes.byref(backdrop), ctypes.sizeof(backdrop))
            dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(corners), ctypes.sizeof(corners))
        except (AttributeError, OSError):
            pass

    def schedule_hide(self, _event=None):
        if self.hide_job:
            self.root.after_cancel(self.hide_job)
        self.hide_job = self.root.after(550, self.hide_if_pointer_left)

    def hide_if_pointer_left(self):
        self.hide_job = None
        x, y = self.pointer_position()
        screen_width = self.root.winfo_screenwidth()
        inside_panel = 0 <= y <= self.height and (screen_width - self.width) // 2 <= x <= (screen_width + self.width) // 2
        if not inside_panel and y > 8:
            self.hide()

    def pointer_position(self):
        point = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(point))
        return point.x, point.y

    def poll_pointer(self):
        x, y = self.pointer_position()
        screen_width = self.root.winfo_screenwidth()
        near_hotspot = abs(x - screen_width // 2) < 110 and y <= 8
        if near_hotspot:
            if not self.snooze_block:
                self.show()
        elif self.visible and self.hide_job is None:
            self.schedule_hide()
        else:
            self.snooze_block = False
        self.root.after(50, self.poll_pointer)

    def close_app(self):
        if self.closing:
            return
        self.closing = True
        if self.is_playing:
            self.media_command("pause")
        self.close_started_at = time.perf_counter()
        self.close_play_item = self.hover_items.get("play_text")
        for item in self.canvas.find_all():
            if item != self.close_play_item:
                self.canvas.itemconfigure(item, state="hidden")
        self.animate_close()

    def animate_close(self):
        elapsed = time.perf_counter() - self.close_started_at
        progress = min(1.0, elapsed / 0.85)
        eased = self.ease_in_out(progress)
        width = self.root.winfo_width() or self.width
        height = self.root.winfo_height() or self.height
        screen_width = self.root.winfo_screenwidth()
        self.root.geometry(f"{width}x{height}+{(screen_width - width) // 2}+0")
        self.draw_close_sides(eased, width, height)
        if progress < 1.0:
            self.root.after(16, self.animate_close)
        else:
            self.media_worker_stop.set()
            if self.popout:
                self.popout.destroy()
            self.root.destroy()

    def draw_close_sides(self, progress, width, height):
        self.canvas.delete("all")
        gap = width * (1.0 - progress)
        panel_width = (width - gap) / 2.0
        self.canvas.create_rectangle(0, 0, panel_width, height, fill="#31414c", outline="#a5bac7", width=1)
        self.canvas.create_rectangle(width - panel_width, 0, width, height, fill="#31414c", outline="#a5bac7", width=1)
        self.canvas.create_line(panel_width, 0, panel_width, height, fill="#b6d0dc", width=1)
        self.canvas.create_line(width - panel_width, 0, width - panel_width, height, fill="#b6d0dc", width=1)

    @staticmethod
    def ease_in_out(value):
        value = max(0.0, min(1.0, value))
        return value * value * (3.0 - 2.0 * value)

    def draw_close_scene(self, stage, progress, width, height):
        self.canvas.delete("all")
        self.canvas.create_rectangle(0, 0, width, height, fill="#31414c", outline="#a5bac7", width=1)
        spin = ("⏸", "╱", "—", "╲")[int(progress * 16) % 4]
        if stage == 0:
            self.canvas.create_text(width // 2, height // 2, text=f"‹  {spin}  ›", fill="#edf6ff", font=("Segoe UI", 16, "bold"))
        elif stage == 1:
            for index in range(5):
                x = width // 2 - 128 + index * 64
                self.canvas.create_rectangle(x, 20, x + 54, height - 18, fill="#536b77", outline="#b5cbd4", width=1)
            if self.artwork_path:
                try:
                    image = Image.open(self.artwork_path).convert("RGB")
                    image.thumbnail((58, 58), Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(image)
                    self.canvas.create_image(width // 2, height // 2, image=photo)
                    self.close_scene_image = photo
                except (OSError, ValueError):
                    pass
        elif stage == 2:
            radius = min(width, height) // 3
            self.canvas.create_oval(width // 2 - radius, height // 2 - radius, width // 2 + radius, height // 2 + radius, fill="#dcecff", outline="#ffffff", width=2)
            self.canvas.create_text(width // 2, height // 2, text="⌖", fill="#31414c", font=("Segoe UI", 28, "bold"))
            self.canvas.create_text(width // 2, height // 2 - radius - 12, text="↑", fill="#dcecff", font=("Segoe UI", 15))
        else:
            self.canvas.create_oval(width // 2 - 4, height // 2 - 4, width // 2 + 4, height // 2 + 4, fill="#dcecff", outline="")

    def toggle_popout(self):
        if self.popout and self.popout.winfo_exists():
            self.popout.destroy()
            if self.rack_window:
                self.rack_window.destroy()
                self.rack_window = None
            self.popout = None
            return
        self.popout = tk.Toplevel(self.root)
        self.popout.overrideredirect(True)
        self.popout.attributes("-topmost", True)
        self.popout.attributes("-transparentcolor", "#111318")
        self.popout.attributes("-alpha", 0.94)
        size = 260
        screen_width = self.root.winfo_screenwidth()
        self.popout.geometry(f"{size}x{size}+{(screen_width - size) // 2}+110")
        self.apply_rounded_region(size, size, self.popout)
        self.popout_canvas = tk.Canvas(self.popout, width=size, height=size, bg="#111318", highlightthickness=0)
        self.popout_canvas.pack(fill="both", expand=True)
        self.popout_canvas.bind("<Button-1>", self.popout_click)
        self.popout_canvas.bind("<B1-Motion>", self.popout_drag)
        self.popout_canvas.bind("<ButtonRelease-1>", self.popout_release)
        self.popout_canvas.bind("<Motion>", self.popout_motion)
        self.popout_canvas.bind("<Leave>", self.schedule_rack_hide)
        self.draw_popout()

    def draw_popout(self):
        if not self.popout_canvas:
            return
        self.popout_rack_images = []
        size = self.popout_size
        self.popout_canvas.delete("all")
        self.popout_canvas.create_rectangle(0, 0, size, size, fill="#31414c", outline="#a5bac7", width=1)
        self.popout_canvas.create_rectangle(2, 2, size - 2, size - 2, outline="#6d8490", width=1)
        self.draw_popout_texture(size)
        self.popout_canvas.create_text(16, 13, anchor="nw", text="↑  ↑  ↑", fill="#d5e7ef", font=("Segoe UI", 9, "bold"))
        self.popout_canvas.create_text(size - 15, 12, anchor="ne", text="×", fill="#f4f8fb", font=("Segoe UI", 13, "bold"))
        if self.artwork_path:
            try:
                image = Image.open(self.artwork_path).convert("RGB")
                image.thumbnail((max(96, size - 70), max(96, size - 120)), Image.Resampling.LANCZOS)
                self.popout_artwork_image = ImageTk.PhotoImage(image)
                self.popout_canvas.create_image(size // 2, int(size * 0.38), image=self.popout_artwork_image)
            except (OSError, ValueError):
                pass
        title_font = tkfont.Font(family="Segoe UI", size=13, weight="bold")
        self.popout_canvas.create_text(18, size - 72, anchor="w", width=size - 36, text=self.fit_text(self.media_title, title_font, size - 36), fill="#f5f8fb", font=title_font)
        self.popout_canvas.create_text(18, size - 45, anchor="w", width=size - 36, text=self.fit_text(self.media_artist, tkfont.Font(family="Segoe UI", size=9), size - 36), fill="#c8d4dc", font=("Segoe UI", 9))
        controls = ((28, "↶"), (size // 2, "⏸" if self.is_playing else "▶"), (size - 28, "→"))
        for x, icon in controls:
            self.popout_canvas.create_oval(x - 16, size - 34, x + 16, size - 2, fill="#dcecff", outline="")
            self.popout_canvas.create_text(x, size - 18, text=icon, fill="#1a2730", font=("Segoe UI", 11, "bold"))

    def draw_popout_texture(self, size):
        for index in range(28):
            x = (index * 47) % size
            y = (index * 29) % size
            self.popout_canvas.create_oval(x, y, x + 1, y + 1, fill="#5e7580", outline="")

    def draw_album_rack(self, size):
        covers = self.artwork_history[-4:]
        for index, path in enumerate(reversed(covers)):
            try:
                image = Image.open(path).convert("RGB")
                image.thumbnail((size - 70, 42), Image.Resampling.LANCZOS)
                rack_image = ImageTk.PhotoImage(image)
                y = 24 - index * 7 + self.popout_rack_offset
                self.popout_canvas.create_image(size // 2, y, image=rack_image)
                if not hasattr(self, "popout_rack_images"):
                    self.popout_rack_images = []
                self.popout_rack_images.append(rack_image)
            except (OSError, ValueError):
                pass

    def create_rack_window(self):
        self.rack_window = tk.Toplevel(self.popout)
        self.rack_window.overrideredirect(True)
        self.rack_window.attributes("-topmost", True)
        self.rack_window.attributes("-transparentcolor", "#111318")
        self.rack_window.attributes("-alpha", 0.94)
        self.rack_canvas = tk.Canvas(self.rack_window, width=230, height=90, bg="#111318", highlightthickness=0)
        self.rack_canvas.pack(fill="both", expand=True)
        self.apply_rounded_region(230, 90, self.rack_window)
        self.rack_canvas.bind("<Motion>", self.rack_motion)
        self.rack_canvas.bind("<Leave>", self.schedule_rack_hide)
        self.draw_rack_window()
        self.position_rack_window(-78)
        self.rack_window.withdraw()

    def draw_rack_window(self):
        if not self.rack_canvas:
            return
        self.rack_canvas.delete("all")
        self.rack_canvas.create_rectangle(0, 0, 230, 90, fill="#31414c", outline="#a5bac7", width=1)
        covers = self.artwork_history[-3:]
        for index, path in enumerate(reversed(covers)):
            try:
                image = Image.open(path).convert("RGB")
                image.thumbnail((58, 58), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(image)
                x = 24 + index * 68
                self.rack_canvas.create_image(x, 46, image=photo)
                if not hasattr(self, "rack_images"):
                    self.rack_images = []
                self.rack_images.append(photo)
            except (OSError, ValueError):
                pass

    def position_rack_window(self, y_offset):
        if not self.rack_window or not self.popout:
            return
        x = self.popout.winfo_x() + (self.popout_size - 230) // 2
        y = self.popout.winfo_y() - 90 + y_offset
        self.rack_window.geometry(f"230x90+{x}+{y}")

    def show_rack_window(self):
        if not self.rack_window:
            return
        self.rack_visible = True
        self.rack_window.deiconify()
        self.rack_window.lower(self.popout)
        self.animate_rack_window(0.0)

    def hide_rack_window(self):
        if not self.rack_window:
            return
        self.rack_visible = False
        self.animate_rack_window(-78.0)

    def animate_rack_window(self, target):
        if not self.rack_window:
            return
        current = self.rack_window.winfo_y() - (self.popout.winfo_y() - 90)
        distance = target - current
        if abs(distance) < 2:
            self.position_rack_window(target)
            if target < 0:
                self.rack_window.withdraw()
            return
        self.position_rack_window(current + distance * 0.22)
        self.root.after(16, lambda: self.animate_rack_window(target))

    def rack_motion(self, _event):
        if not self.rack_visible:
            self.show_rack_window()

    def schedule_rack_hide(self, _event=None):
        if self.rack_hide_job:
            self.root.after_cancel(self.rack_hide_job)
        self.rack_hide_job = self.root.after(250, self.hide_rack_if_pointer_left)

    def hide_rack_if_pointer_left(self):
        self.rack_hide_job = None
        x, y = self.pointer_position()
        popout_inside = self.popout and self.popout.winfo_x() <= x <= self.popout.winfo_x() + self.popout_size and self.popout.winfo_y() <= y <= self.popout.winfo_y() + self.popout_size
        rack_inside = self.rack_window and self.rack_window.winfo_x() <= x <= self.rack_window.winfo_x() + 230 and self.rack_window.winfo_y() <= y <= self.rack_window.winfo_y() + 90
        if not popout_inside and not rack_inside:
            self.hide_rack_window()

    def popout_click(self, event):
        size = self.popout_size
        if event.x >= size - 34 and event.y <= 34:
            self.popout.destroy()
            self.popout = None
        elif event.y >= size - 38 and event.x < size / 3:
            self.media_command("seek", 0)
        elif event.y >= size - 38 and size / 3 <= event.x <= size * 2 / 3:
            self.media_command("playpause")
        elif event.y >= size - 38 and event.x > size * 2 / 3:
            self.media_command("next")
        else:
            self.popout_drag_origin = (event.x_root, event.y_root, self.popout.winfo_x(), self.popout.winfo_y())

    def popout_motion(self, event):
        self.popout.configure(cursor="arrow")

    def popout_drag(self, event):
        if self.popout_drag_origin:
            start_x, start_y, window_x, window_y = self.popout_drag_origin
            self.popout.geometry(f"{self.popout_size}x{self.popout_size}+{window_x + event.x_root - start_x}+{window_y + event.y_root - start_y}")

    def popout_release(self, _event):
        self.popout_drag_origin = None

    def start_rack_cycle(self):
        if len(self.artwork_history) < 2:
            return
        self.popout_rack_index = (self.popout_rack_index + 1) % min(4, len(self.artwork_history))
        self.popout_rack_offset = -18.0
        self.animate_rack_offset()
        self.popout_rack_job = self.root.after(850, self.start_rack_cycle)

    def animate_rack_offset(self):
        if not self.popout or not self.popout.winfo_exists() or not self.popout_rack_open:
            return
        self.popout_rack_offset += (0.0 - self.popout_rack_offset) * 0.18
        self.draw_popout()
        if abs(self.popout_rack_offset) > 0.5:
            self.root.after(16, self.animate_rack_offset)

    def send_media_key(self, virtual_key):
        user32.keybd_event(virtual_key, 0, 0, 0)
        user32.keybd_event(virtual_key, 0, KEYEVENTF_KEYUP, 0)

    def media_command(self, command, value=None):
        if not __import__("os").path.exists(self.bridge_path):
            return False
        arguments = ["dotnet", self.bridge_path, command]
        if value is not None:
            arguments.append(str(value))
        try:
            subprocess.run(arguments, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=2)
            return True
        except (OSError, subprocess.SubprocessError):
            return False

    def read_media_status(self):
        if not __import__("os").path.exists(self.bridge_path):
            return None
        try:
            result = subprocess.run(
                ["dotnet", self.bridge_path, "status"],
                capture_output=True, text=True,
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=2,
            )
            if not result.stdout.strip() or result.stdout.strip() == "null":
                return ("Now Playing", "Connect a media app to see track details", "", None, 0.0, "", False)
            media = json.loads(result.stdout)
            title = media.get("title") or "Now Playing"
            artist = media.get("artist") or media.get("source", "Media session")
            artwork = media.get("artwork") or ""
            status = media.get("status", "")
            duration = max(0.0, float(media.get("duration", 0))) or None
            position = max(0.0, float(media.get("position", 0)))
            spotify = "spotify" in media.get("source", "").lower()
            return (title, artist, artwork, duration, position, status, spotify)
        except (OSError, subprocess.SubprocessError, ValueError, json.JSONDecodeError):
            return None

    def on_click(self, event):
        width = self.canvas.winfo_width()
        center = width // 2
        track_left = 300
        track_right = width - 300
        volume_left = width - 235
        volume_right = width - 90
        if volume_left <= event.x <= volume_right and 66 <= event.y <= 80:
            self.set_volume_level((event.x - volume_left) / (volume_right - volume_left))
        elif track_left <= event.x <= track_right and 56 <= event.y <= 76:
            self.dragging = True
            self.set_progress_from_x(event.x)
            if self.duration_seconds:
                self.media_command("seek", self.target_progress * self.duration_seconds)
        elif center - 94 <= event.x <= center - 56 and 13 <= event.y <= 49:
            self.pulse_button("prev")
            self.media_command("previous")
        elif center - 24 <= event.x <= center + 24 and 8 <= event.y <= 56:
            self.pulse_button("play")
            self.media_command("playpause")
        elif center + 56 <= event.x <= center + 94 and 13 <= event.y <= 49:
            self.pulse_button("next")
            self.media_command("next")
        elif width - 260 <= event.x <= width - 230 and 16 <= event.y <= 48:
            self.pulse_button("shuffle")
            self.shuffle_enabled = not self.shuffle_enabled
            self.media_command("shuffle", self.shuffle_enabled)
            self.draw()
        elif width - 220 <= event.x <= width - 190 and 16 <= event.y <= 48:
            self.pulse_button("repeat")
            self.repeat_enabled = not self.repeat_enabled
            self.media_command("repeat", 1 if self.repeat_enabled else 0)
            self.draw()
        elif width - 180 <= event.x <= width - 150 and 16 <= event.y <= 48:
            self.pulse_button("device")
            self.toggle_popout()
        elif width - 140 <= event.x <= width - 110 and 16 <= event.y <= 48:
            self.pulse_button("volume")
            self.send_media_key(VK_VOLUME_MUTE)
        elif width - 100 <= event.x <= width - 70 and 16 <= event.y <= 48:
            self.pulse_button("snooze")
            self.snooze_block = True
            self.hide()
        elif width - 60 <= event.x <= width - 30 and 16 <= event.y <= 48:
            self.pulse_button("close")
            self.close_app()

    def on_seek_drag(self, event):
        volume_left = self.canvas.winfo_width() - 235
        volume_right = self.canvas.winfo_width() - 90
        if volume_left <= event.x <= volume_right and 66 <= event.y <= 80:
            self.set_volume_level((event.x - volume_left) / (volume_right - volume_left))
            return
        track_left = 300
        track_right = self.canvas.winfo_width() - 300
        if self.dragging and 56 <= event.y <= 76:
            self.set_progress_from_x(max(track_left, min(track_right, event.x)))

    def on_seek_release(self, event):
        track_left = 300
        track_right = self.canvas.winfo_width() - 300
        was_dragging = self.dragging
        self.dragging = False
        if was_dragging and track_left <= event.x <= track_right and 56 <= event.y <= 76 and self.duration_seconds:
            self.set_progress_from_x(max(track_left, min(track_right, event.x)))
            self.media_command("seek", self.target_progress * self.duration_seconds)

    def set_progress_from_x(self, x):
        track_left = 300
        track_right = self.canvas.winfo_width() - 300
        self.target_progress = max(0.0, min(1.0, (x - track_left) / (track_right - track_left)))
        if self.duration_seconds is not None:
            self.elapsed_seconds = self.target_progress * self.duration_seconds
        self.update_progress()

    def on_motion(self, event):
        previous_hover = self.hover_target
        width = self.canvas.winfo_width()
        center = width // 2
        if 78 <= event.x <= getattr(self, "title_right", 266) and 14 <= event.y <= 45:
            self.hover_target = "title"
        elif 78 <= event.x <= getattr(self, "subtitle_right", 266) and 45 <= event.y <= 68:
            self.hover_target = "subtitle"
        elif center - 94 <= event.x <= center - 56 and 13 <= event.y <= 49:
            self.hover_target = "prev"
        elif center - 24 <= event.x <= center + 24 and 8 <= event.y <= 56:
            self.hover_target = "play"
        elif center + 56 <= event.x <= center + 94 and 13 <= event.y <= 49:
            self.hover_target = "next"
        elif width - 260 <= event.x <= width - 230 and 16 <= event.y <= 48:
            self.hover_target = "shuffle"
        elif width - 220 <= event.x <= width - 190 and 16 <= event.y <= 48:
            self.hover_target = "repeat"
        elif width - 180 <= event.x <= width - 150 and 16 <= event.y <= 48:
            self.hover_target = "device"
        elif width - 140 <= event.x <= width - 110 and 16 <= event.y <= 48:
            self.hover_target = "volume"
        elif width - 100 <= event.x <= width - 70 and 16 <= event.y <= 48:
            self.hover_target = "snooze"
        elif width - 60 <= event.x <= width - 30 and 16 <= event.y <= 48:
            self.hover_target = "close"
        else:
            self.hover_target = None
        if previous_hover != self.hover_target:
            self.draw()

    def refresh(self):
        changed = False
        try:
            while True:
                snapshot = self.media_updates.get_nowait()
                changed = self.apply_media_snapshot(snapshot) or changed
        except queue.Empty:
            pass
        self.custom_tick()
        if changed and self.visible:
            self.draw()
        if changed and self.popout and self.popout.winfo_exists():
            self.draw_popout()
        self.root.after(1000, self.refresh)

    def media_worker(self):
        while not self.media_worker_stop.is_set():
            snapshot = self.read_media_status()
            self.media_updates.put(snapshot)
            self.media_worker_stop.wait(1.0)

    def apply_media_snapshot(self, snapshot):
        if snapshot is None:
            return False
        previous_key = (self.media_title, self.media_artist, self.duration_seconds, self.artwork_path, self.media_status)
        self.media_title, self.media_artist, self.artwork_path, self.duration_seconds, self.elapsed_seconds, self.media_status, self.spotify_running = snapshot
        if self.artwork_path and self.artwork_path not in self.artwork_history:
            self.artwork_history.append(self.artwork_path)
            self.artwork_history = self.artwork_history[-8:]
        self.is_playing = self.media_status.lower() == "playing"
        if self.duration_seconds:
            self.progress = max(0.0, min(1.0, self.elapsed_seconds / self.duration_seconds))
            self.target_progress = self.progress
        current_key = (self.media_title, self.media_artist, self.duration_seconds, self.artwork_path, self.media_status)
        return previous_key != current_key

    def detect_spotify(self):
        try:
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq Spotify.exe"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW,
                timeout=1,
            )
            self.spotify_running = "Spotify.exe" in result.stdout
        except (OSError, subprocess.SubprocessError):
            self.spotify_running = False

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    CubbyCustom().run()
