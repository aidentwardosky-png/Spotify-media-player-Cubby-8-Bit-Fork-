# Cubby Custom

Editable native Windows Python starter inspired by Cubby's top center media panel. This is a desktop script

## Run

Double-click `run_cubby.bat`, or run this from PowerShell:

```powershell
python cubby_custom.py
```

Move the mouse to the top-center of the screen to reveal the panel. Click the panel to send the Windows media play/pause key. The progress bar is clickable and currently visual only. sorry lol

## key notes

 This project is an edited starter, not a decompiled copy.
